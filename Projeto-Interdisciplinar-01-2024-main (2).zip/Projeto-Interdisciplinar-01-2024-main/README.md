# Projeto-Interdisciplinar-01-2024
Projeto Interdisciplinar do Primeiro Semestre do Curso de Desenvolvimento de Software Multiplataformas na Instituição FATEC Araras, 2024.


Para o projeto interdisciplinar, nosso grupo busca uma forma de combater a falta de inclusão na educação. Propomos a criação de um website de apoio à educação onde o foco será o auxílio a alunos com deficiências auditivas. O website permitirá que alunos enviem videoaulas de seu interesse, gerando videoaulas com acessibilidade especializada (Legendas e LIBRAS).

